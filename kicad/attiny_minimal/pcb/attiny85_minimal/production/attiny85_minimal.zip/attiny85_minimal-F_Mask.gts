G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.2*
G04 #@! TF.CreationDate,2025-05-22T10:34:26+02:00*
G04 #@! TF.ProjectId,attiny85_minimal,61747469-6e79-4383-955f-6d696e696d61,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.2) date 2025-05-22 10:34:26*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
